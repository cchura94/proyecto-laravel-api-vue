<template>
    <h1>Este es mi componente Tabla</h1>
</template>
<style scoped>
h1{
    color: blue;
}
</style>