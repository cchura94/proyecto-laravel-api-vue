<template>
    <h1>Mi Registro de Usuario</h1>
</template>