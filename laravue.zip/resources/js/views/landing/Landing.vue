<template>
    <h1>Pagina Web</h1>
    <router-link to="/">INICIO</router-link> |
    <router-link to="/blog">BLOG</router-link> |
    <router-link to="/login">INGRESAR</router-link> |
    <router-link to="/registro">REGISTRO</router-link> |
    <router-link to="/perfil">PERFIL</router-link> |
    <router-link to="/usuario">USUARIO</router-link> 

    <router-view></router-view>
</template>