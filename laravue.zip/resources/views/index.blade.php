<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi App Vue + Laravel</title>
    <link id="theme-css" rel="stylesheet" type="text/css" href="/themes/lara-light-indigo/theme.css">
</head>
<body>
    <div id="app"></div>
    
    @vite('resources/js/app.js')
</body>
</html>